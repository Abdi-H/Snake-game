﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;
using System.Media;

namespace SnakeGame
{
    public partial class SnakeGame : Form
    {
        private GameStateManager GameManager { get; set; }
        private static String OutputFileName = "Snake.txt";

        public SnakeGame()
        {
            InitializeComponent();

            timer.Interval = GameStateManager.TimerTick;
            timer.Tick += timerTick;
            timer.Start();

            GameStateManager manager = new GameStateManager();
            GameManager = manager;

            imgGameBackground.BackColor = GameStateManager.BackgroundColor;
            this.KeyPreview = true;
            StartGame();
        }

        /// <summary>
        /// Every time the timer elapse the tick, update the game
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timerTick(object sender, EventArgs e)
        {
            if (!GameManager.IsGamePaused && !GameManager.IsGameOver)
            {
                timer.Stop();
                MoveSnake();
                imgGameBackground.Invalidate();
                timer.Start();
            }
        }

        /// <summary>
        /// Handle events when keys are pressed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void KeyPressedDown(object sender, KeyEventArgs e)
        {
            if (GameManager.IsGameOver == true)
            {
                // if the game over is true and player presses enter
                // we run the start game function
                if (e.KeyCode == Keys.R)
                {
                    StartGame();
                }
            }
            else
            {
                //checks the current input and make sure it's not complete
                //opposite of the current direction
                if (e.KeyCode == Keys.Left || e.KeyCode == Keys.A)
                {
                    if (GameManager.CurrentSnakeDirection != Directions.Right)
                    {
                        GameManager.CurrentSnakeDirection = Directions.Left;
                    }
                }
                else if (e.KeyCode == Keys.Right || e.KeyCode == Keys.D)
                {
                    if (GameManager.CurrentSnakeDirection != Directions.Left)
                    {
                        GameManager.CurrentSnakeDirection = Directions.Right;
                    }
                }
                else if (e.KeyCode == Keys.Up || e.KeyCode == Keys.W)
                {
                    if (GameManager.CurrentSnakeDirection != Directions.Down)
                    {
                        GameManager.CurrentSnakeDirection = Directions.Up;
                    }
                }
                else if (e.KeyCode == Keys.Down || e.KeyCode == Keys.S)
                {
                    if (GameManager.CurrentSnakeDirection != Directions.Up)
                    {
                        GameManager.CurrentSnakeDirection = Directions.Down;
                    }
                }
                else if (e.KeyCode == Keys.P)
                {
                    GameManager.IsGamePaused = !GameManager.IsGamePaused;
                }
            }

            imgGameBackground.Invalidate(); //invalidate and cause the image to refresh.
        }

        /// <summary>
        /// Starts the game
        /// </summary>
        private void StartGame()
        {
            //hide the game over label
            lblResult.Visible = false;
            GameManager.reset();
            GameManager.Snake.Clear();
            
            GameBlock snakeHead = new GameBlock(0, 0);
            GameManager.Snake.Add(snakeHead);
            lblScoreVal.Text = "0";

            CreateApple();
        }

        /// <summary>
        /// Moves the whole snake
        /// </summary>
        private void MoveSnake()
        {
            int prevX = 0;
            int prevY = 0;
            int size = GameStateManager.ObjectSize;
            //loops through the snake head and body and move the snake to the current direction
            //we're starting from the top

            List<GameBlock> snake = GameManager.Snake;
            int count = snake.Count;
            for (int i = 0; i < count; i++)
            {
                // if the snake head is active 
                if (i == 0)
                {
                    prevX = snake[i].X;
                    prevY = snake[i].Y;
                    // move rest of the body according to which way the head is moving
                    switch (GameManager.CurrentSnakeDirection)
                    {
                        case Directions.Right:
                            snake[0].X+=GameStateManager.SnakeMoveSpeed;
                            break;
                        case Directions.Left:
                            snake[0].X-=GameStateManager.SnakeMoveSpeed;
                            break;
                        case Directions.Up:
                            snake[0].Y-= GameStateManager.SnakeMoveSpeed;
                            break;
                        case Directions.Down:
                            snake[0].Y+= GameStateManager.SnakeMoveSpeed;
                            break;
                    }

                    // get the max x and y and make sure the snake's head hasnt hit it
                    int maxX = imgGameBackground.Size.Width - size;
                    int maxY = imgGameBackground.Size.Height -size;

                    if (snake[0].X < 0 || snake[0].Y < 0
                        || snake[0].X > maxX || snake[i].Y > maxY)
                    {
                        //if the snake hits the max pos, end the game
                        EndGame();
                        break;
                    }

                    GameBlock apple = GameManager.Apple;
                    Rectangle headRec = new Rectangle(snake[0].X, snake[0].Y, size, size);
                    Rectangle appleRec = new Rectangle(apple.X, apple.Y, size, size);

                    if (headRec.IntersectsWith(appleRec))
                    {
                        //if we only have the head then the body should spawn at head's prev position
                        if (snake.Count == 1)
                        {
                            EatApple(prevX, prevY);
                        }
                        else
                        {
                            //otherwise use the tail of the snake pos before we move the rest of the body
                            GameBlock tail = snake[snake.Count - 1];
                            EatApple(tail.X, tail.Y);
                        }
                    }
                }
                else
                {
                    int newPrevX = snake[i].X;
                    int newPrevY = snake[i].Y;
                    //move the rest of the snake's body
                    snake[i].X = prevX;
                    snake[i].Y = prevY;

                    prevX = newPrevX;
                    prevY = newPrevY;

                    // after moving the each snake body, detect collision with the body
                    // this loop will check if the snake had an collision with other body parts
                    Rectangle headRec = new Rectangle(snake[0].X, snake[0].Y, size, size);
                    Rectangle body = new Rectangle(snake[i].X, snake[i].Y, size, size);

                    if (headRec.IntersectsWith(body))
                    {
                        EndGame();
                        break;
                    }
                }                 
            }
        }

        /// <summary>
        /// Creates the apple at a random spot on the map
        /// </summary>
        private void CreateApple()
        {
            //create the apple at any points in the image
            int objectSize = GameStateManager.ObjectSize;
            int maxX = imgGameBackground.Size.Width - objectSize*2;
            int maxY = imgGameBackground.Size.Height - objectSize*2;

            Random rng = new Random();
            int x = rng.Next(objectSize*2, maxX);
            int y = rng.Next(objectSize*2, maxY);
         
            GameBlock apple = new GameBlock(x, y);
            GameManager.Apple = apple;
        }

        /// <summary>
        /// Eat the apple, increase points and increase snake size
        /// </summary>
        /// <param name="newBodyX"></param>
        /// <param name="newBodyY"></param>
        private void EatApple(int newBodyX, int newBodyY)
        {
            //increase snake body and update the points
            IncreaseSnakeBody(newBodyX, newBodyY);
            GameManager.CurrentScore += GameStateManager.ApplePoint;
            lblScoreVal.Text = $"{GameManager.CurrentScore}";
            if (GameManager.CurrentScore > GameManager.HighestScore)
            {
                GameManager.HighestScore = GameManager.CurrentScore;
            }
            //create a new apple somewhere
            CreateApple(); 
        }

        /// <summary>
        /// Increase the size of the snake
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        private void IncreaseSnakeBody(int x, int y)
        {
            GameBlock block = new GameBlock(x, y);
            GameManager.Snake.Add(block);
        }

        /// <summary>
        /// End the game
        /// </summary>
        private void EndGame()
        {
            GameManager.IsGameOver = true;
        }

        /// <summary>
        /// repaint the game map
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void imgGameBackground_Paint(object sender, PaintEventArgs e)
        {
            if (!GameManager.IsGameOver)
            {
                //draw the snake
                Graphics canvas = e.Graphics; // create a new graphics class called canvas
                int size = GameStateManager.ObjectSize;
                Brush bodyColor = GameStateManager.SnakeBodyColor;
                Brush headColor = GameStateManager.SnakeHeadColor;

                List<GameBlock> snake = GameManager.Snake;
                //draw all the snakes using the game blocks
                for (int i = 0; i < snake.Count; i++)
                {
                    Brush color;
                    if (i == 0)
                    {
                        //head of the snake
                        color = headColor;
                        canvas.FillRectangle(color, new Rectangle(snake[i].X, snake[i].Y, size, size));
                    }
                    else
                    {
                        color = bodyColor;
                        //draw snake body and head
                        canvas.FillEllipse(color, new Rectangle(snake[i].X, snake[i].Y, size, size));
                    }
                }

                GameBlock apple = GameManager.Apple;
                // draw apple
                canvas.FillRectangle(GameStateManager.AppleColor, new Rectangle(apple.X, apple.Y, size, size));
                lblScoreVal.Text = $"{GameManager.CurrentScore}";
            }
            else
            {
                //shows the game over message
                string gameOver = $"Game Over! Your Score is \" {GameManager.CurrentScore}\" \nPress R to Restart";
                lblResult.Text = gameOver;
                lblResult.Visible = true;
                SoundPlayer simpleSound = new SoundPlayer(@"c:\Windows\Media\tada.wav");


                simpleSound.Play
                ();
            }

            lblHighestScoreVal.Text = $"{GameManager.HighestScore}";
        }

        /// <summary>
        /// Saves the game state to a text file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            String fullPath = Directory.GetCurrentDirectory() + "\\" + OutputFileName;
            IFormatter formatter = new BinaryFormatter();
            using (Stream stream = new FileStream(fullPath, FileMode.Create, FileAccess.Write))
            {
                formatter.Serialize(stream, GameManager);
            }
        }

        /// <summary>
        /// Load the game from existing saved file and reset the game state
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLoad_Click(object sender, EventArgs e)
        {
            String fullPath = Directory.GetCurrentDirectory() + "\\" + OutputFileName;
            if (File.Exists(fullPath))
            {
                int highestScore = GameManager.HighestScore;
                IFormatter formatter = new BinaryFormatter();
                using (Stream stream = new FileStream(fullPath, FileMode.Open, FileAccess.Read))
                {
                    GameManager = (GameStateManager)formatter.Deserialize(stream);
                    if (highestScore > GameManager.HighestScore)
                    {
                        GameManager.HighestScore = highestScore;
                    }
                    lblResult.Visible = false;
                }
            }
        }
    }
}

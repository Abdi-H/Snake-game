﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SnakeGame
{
    public enum Directions
    {
        //enums to store all the different directions we can do in the game
        Left,
        Right,
        Up,
        Down
    };
}

﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace SnakeGame
{
    [Serializable]
    class GameStateManager
    {
        //constant variables for game settings
        public static Brush SnakeBodyColor = Brushes.Green;
        public static Brush SnakeHeadColor = Brushes.DarkGreen;
        public static Brush AppleColor = Brushes.Red;
        public static int ObjectSize = 10;
        public static Color BackgroundColor = Color.Black;
        public static int TimerTick = 200;
        public static int SnakeMoveSpeed = 15;
        public static int ApplePoint = 10; 
        
        /// <summary>
        /// Holds the whole snake
        /// </summary>
        public List<GameBlock> Snake { get; set; }

        /// <summary>
        /// Holds the apple
        /// </summary>
        public GameBlock Apple { get; set; }

        /// <summary>
        /// Determine if game is over
        /// </summary>
        public Boolean IsGameOver { get; set; }
        /// <summary>
        /// Detemrine if game is paused
        /// </summary>
        public Boolean IsGamePaused { get; set; }
        /// <summary>
        /// Holds current game score
        /// </summary>
        public int CurrentScore { get; set; }
        /// <summary>
        /// Holds current snake's direction
        /// </summary>
        public Directions CurrentSnakeDirection { get; set; }

        /// <summary>
        /// Holds highest score in the game
        /// </summary>
        public int HighestScore { get; set; }

        public GameStateManager()
        {
            IsGameOver = false;
            IsGamePaused = false;
            CurrentScore = 0;
            CurrentSnakeDirection = Directions.Right;
            HighestScore = 0;
            Snake = new List<GameBlock>();
        }

        public void reset()
        {
            IsGameOver = false;
            IsGamePaused = false;
            CurrentScore = 0;
            CurrentSnakeDirection = Directions.Right;
        }
    }
}

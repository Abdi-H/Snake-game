﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SnakeGame
{
    [Serializable]
    class GameBlock
    { 
        //holds X coordinate of the block
        public int X { get; set; } 

        //holds Y corrdinate of the block
        public int Y { get; set; } 

        /// <summary>
        /// initialize block with the given x and y corrdinates of zero
        /// </summary>
        public GameBlock()
        {
            X = 0;
            Y = 0;
        }

        /// <summary>
        /// initialize block with the given x and y corrdinates
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public GameBlock(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}

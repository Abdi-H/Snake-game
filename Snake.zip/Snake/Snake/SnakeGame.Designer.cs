﻿
namespace SnakeGame
{
    partial class SnakeGame
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.imgGameBackground = new System.Windows.Forms.PictureBox();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblScoreVal = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.lblHighestScoreVal = new System.Windows.Forms.Label();
            this.lblHighestScore = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.imgGameBackground)).BeginInit();
            this.SuspendLayout();
            // 
            // imgGameBackground
            // 
            this.imgGameBackground.Location = new System.Drawing.Point(14, 137);
            this.imgGameBackground.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.imgGameBackground.Name = "imgGameBackground";
            this.imgGameBackground.Size = new System.Drawing.Size(630, 421);
            this.imgGameBackground.TabIndex = 0;
            this.imgGameBackground.TabStop = false;
            this.imgGameBackground.Paint += new System.Windows.Forms.PaintEventHandler(this.imgGameBackground_Paint);
            // 
            // lblScore
            // 
            this.lblScore.AccessibleName = "";
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblScore.Location = new System.Drawing.Point(14, 61);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(126, 46);
            this.lblScore.TabIndex = 1;
            this.lblScore.Text = "Score: ";
            // 
            // lblScoreVal
            // 
            this.lblScoreVal.AccessibleName = "";
            this.lblScoreVal.AutoSize = true;
            this.lblScoreVal.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblScoreVal.Location = new System.Drawing.Point(137, 61);
            this.lblScoreVal.Name = "lblScoreVal";
            this.lblScoreVal.Size = new System.Drawing.Size(38, 46);
            this.lblScoreVal.TabIndex = 2;
            this.lblScoreVal.Text = "0";
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.BackColor = System.Drawing.Color.Black;
            this.lblResult.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblResult.ForeColor = System.Drawing.Color.Red;
            this.lblResult.Location = new System.Drawing.Point(98, 247);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(116, 35);
            this.lblResult.TabIndex = 3;
            this.lblResult.Text = "You Lost!";
            this.lblResult.Visible = false;
            // 
            // lblHighestScoreVal
            // 
            this.lblHighestScoreVal.AccessibleName = "";
            this.lblHighestScoreVal.AutoSize = true;
            this.lblHighestScoreVal.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblHighestScoreVal.Location = new System.Drawing.Point(259, 12);
            this.lblHighestScoreVal.Name = "lblHighestScoreVal";
            this.lblHighestScoreVal.Size = new System.Drawing.Size(38, 46);
            this.lblHighestScoreVal.TabIndex = 5;
            this.lblHighestScoreVal.Text = "0";
            // 
            // lblHighestScore
            // 
            this.lblHighestScore.AccessibleName = "";
            this.lblHighestScore.AutoSize = true;
            this.lblHighestScore.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblHighestScore.Location = new System.Drawing.Point(14, 12);
            this.lblHighestScore.Name = "lblHighestScore";
            this.lblHighestScore.Size = new System.Drawing.Size(258, 46);
            this.lblHighestScore.TabIndex = 4;
            this.lblHighestScore.Text = "Highest Score: ";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(457, 29);
            this.btnSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(86, 31);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(457, 68);
            this.btnLoad.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(86, 31);
            this.btnLoad.TabIndex = 7;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // SnakeGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(656, 577);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblHighestScoreVal);
            this.Controls.Add(this.lblHighestScore);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.lblScoreVal);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.imgGameBackground);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "SnakeGame";
            this.Text = "Snake";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyPressedDown);
            ((System.ComponentModel.ISupportInitialize)(this.imgGameBackground)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox imgGameBackground;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblScoreVal;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Label lblHighestScore;
        private System.Windows.Forms.Label lblHighestScoreVal;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnLoad;
    }
}

